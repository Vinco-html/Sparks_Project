const showUser=document.querySelector(".share");


 function toggleShow(){
    showUser.classList.toggle("hide");
    console.log(showUser);
}
const showUse=document.querySelector(".success");
function success(){
showUse.classList.toggle("show")
console.log(showUse)

}
const show=document.querySelector(".History");


 function access(){
    show.classList.toggle("here");
    console.log(show);
    
}
const sho=document.querySelector(".leftNav");
 function wed(){
    sho.classList.toggle("switch");
    console.log(sho);
  
    
}